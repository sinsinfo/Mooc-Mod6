//*********************************************************************
//*
//*  basico.js - logica de aplicacion
//*
//*. Juan Antonio Cotobal                                      dic-2017
//*
//*********************************************************************

/*
//--------- codigo original de: ----------------
//  https://developer.mozilla.org/en-US/docs/Web/API/Detecting_device_orientation
var versionMovil=true;
var ball   = document.querySelector('.ball');
var garden = document.querySelector('.garden');
var output = document.querySelector('.output');

var maxX = garden.clientWidth  - ball.clientWidth;
var maxY = garden.clientHeight - ball.clientHeight;

function handleOrientation(event) {
  var x = event.beta;  // In degree in the range [-180,180]
  var y = event.gamma; // In degree in the range [-90,90]

  output.innerHTML  = "beta : " + x + "\n";
  output.innerHTML += "gamma: " + y + "\n";

  // Because we don't want to have the device upside down
  // We constrain the x value to the range [-90,90]
  if (x >  90) { x =  90};
  if (x < -90) { x = -90};

  // To make computation easier we shift the range of 
  // x and y to [0,180]
  x += 90;
  y += 90;

  // 10 is half the size of the ball
  // It center the positioning point to the center of the ball
  ball.style.top  = (maxX*x/180 - 10) + "px";
  ball.style.left = (maxY*y/180 - 10) + "px";
}

window.addEventListener('deviceorientation', handleOrientation);

*/ 
/* jslint white: true */
var app = {
   inicio: function () {
      "use strict";
      bola  ={'x':10, 'y':10,'color':'blue'};
      
      ball   = document.querySelector('.ball');
      garden = document.querySelector('.garden');
      output = document.querySelector('.output');

      maxX = garden.clientWidth  - ball.clientWidth;
      maxY = garden.clientHeight - ball.clientHeight;

      window.addEventListener('deviceorientation', this.handleOrientation);
      alert("app iniciada");
   },
   handleOrientation: function(event) {
     var x = event.beta;  // In degree in the range [-180,180]
     var y = event.gamma; // In degree in the range [-90,90]

     output.innerHTML  = "beta : " + x + "\n";
     output.innerHTML += "gamma: " + y + "\n";

     // Because we don't want to have the device upside down
     // We constrain the x value to the range [-90,90]
     if (x >  90) { x =  90};
     if (x < -90) { x = -90};

     // To make computation easier we shift the range of 
     // x and y to [0,180]
     bola.x += x;
     bola.y += y;
      if ((bola.x>=maxX)||(bola.x<=0)||(bola.y>=maxY)||(bola.y<=0))
         ball.style.backgroundColor='red';
      else
         ball.style.backgroundColor=bola.color;
      if (bola.x>maxX) bola.x=maxX;
      if (bola.x<0)    bola.x=0;
      if (bola.y>maxY) bola.y=maxY;
      if (bola.y<0)    bola.y=0;
      

     // 10 is half the size of the ball
     // It center the positioning point to the center of the ball
     ball.style.top  = bola.x + "px";
     ball.style.left = bola.y + "px";
   },

};


if ('addEventListener' in document){
   document.addEventListener('DOMContentLoaded', function(){
      //alert("DOMContentLoaded");
      app.inicio();
   }, false);
   document.addEventListener('deviceready',function(){
      //alert("deviceready");
      //_mo_.iniciar(_mo_.objetoInicial);
      //app.dispositivoListo();
   }, false);
}
