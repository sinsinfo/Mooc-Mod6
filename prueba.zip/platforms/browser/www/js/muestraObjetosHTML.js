//*******************************************************************
//*******************************************************************
//
//    muestraObjetosHTML.js
//
//    Muestra y permite navegar por las propiedades de un objeto
//
//                                      (C)CIPSA/JAC Vers. 14/12/2017
//*******************************************************************
//*******************************************************************
/*
     Instrucciones. Incluir en una página html:

<!-- ================ muestraObjetosHTML ================ -->
<script src='js/muestraObjetosHTML.js'></script>
<script>_mo_.iniciarCon('tempObject','');</script>
<!-- ================ fin: muestraObjetosHTML ================ -->

    Opcional: en iniciar(); puede indicar el nombre de un objeto. Ej.: iniciar("map");
*/

var tempObject; //Global, auxiliar para examinar objetos internos

var _mo_={
   
nombreObjeto:"window",  //Iniciar las funciones con un nombre de objeto
nombreFiltro:"",   //Iniciar las funciones con un filtro
conFiltro:true,        //Mostrar campo Filtro
fontSize: "1em",     //Tamaño de fuente del div resultado (movil: ".6em")
   
//==========================================
// iniciarCon
// Inicia las funciones con un nombre de objeto y/o filtro
//==========================================
iniciarCon:function(objeto,filtro){
   //alert("iniciarCon('"+objeto+"','"+filtro+"')");
   if (objeto!==undefined){
      this.nombreObjeto=objeto;
      document.getElementById('_mo_divTxt').value=objeto;
   };
   if (filtro!==undefined){
      this.nombreFiltro=filtro;
      document.getElementById('_mo_divFiltro').value=filtro;
   };
   //Si no es con filtro, ocultar campo
   if (!this.conFiltro){
         document.getElementById('_mo_divFiltro').style.display='none';
   };
   //Mostrar ya
   //this.mostrarObjetoHTML(objeto,filtro);
},
//==========================================
// iniciar
// Pinta el texto y botón "Mostrar"
//==========================================
   
iniciar:function(nombreObjeto){
    
    //Si no hay parametro, poner "screen"
    //nombreObjeto = nombreObjeto || "screen";
  
    document.body.innerHTML+="<input type='text' id='_mo_divTxt' name='_mo_divTxt' value='" + this.nombreObjeto + "' size='20' placeholder='(nombre de objeto)' style='background-color:#eeffee;' onkeyup=\"_mo_.mostrarObjetoHTML(document.getElementById('_mo_divTxt').value,document.getElementById('_mo_divFiltro').value);\" >";
   
    document.body.innerHTML+="<input type='text' id='_mo_divFiltro' name='_mo_divFiltro' value='" + this.nombreFiltro + "' size='6' placeholder='(filtro)' style='background-color:#eeffee;'  onkeyup=\"_mo_.mostrarObjetoHTML(document.getElementById('_mo_divTxt').value,document.getElementById('_mo_divFiltro').value);\" >";

    document.body.innerHTML+="<button onclick=\"_mo_.mostrarObjetoHTML(document.getElementById('_mo_divTxt').value,document.getElementById('_mo_divFiltro').value);\">Mostrar</button>";

    document.body.innerHTML+="<div id='_mo_divResult'>&nbsp;</div>";
}, //iniciar

//==========================================
// mostrarObjetoHTML
// Toma información del objeto y lo presenta en el área de texto
//==========================================
mostrarObjetoHTML: function(objeto,filtro){
   
   //alert("mostrarObjetoHTML('"+objeto+"','"+filtro+"')");
   this.nombreObjeto=objeto;
   this.nombreFiltro=filtro;
   
   //Comprobaciones y estilos
   divResult=document.getElementById('_mo_divResult');
   divResult.style.fontSize=this.fontSize;
   divResult.style.display = "block";
   divResult.style.backgroundColor = "#eeffee";
   divResult.style.border="1px solid silver";
   divResult.style.width="95%";
   divResult.style.marginTop="5px";
   divResult.style.marginBottom="5px";
   
   divResult.innerHTML=this.infoObjeto(objeto);
}, //mostrarObjetoHTML
   
//==========================================
// infoObjeto
// Pinta el html con las propiedades de un objeto determinado
//==========================================
infoObjeto: function(rutaObjeto) {
   var txtObjeto="";
   var txtError="";
   
   //====== Limpiar y adaptar ruta ".[" --> "["
   var rutaObjeto_ok=rutaObjeto.replace(/\.\[/g,"\[");
   document.getElementById('_mo_divTxt').value=rutaObjeto_ok;
   var objeto;
   
   //-------- Mensajes de error -------------
   try{
      objeto=eval(rutaObjeto_ok);
   } catch (err) {
      txtError+="<p><b>Error:</b><i>"+err+"</i></p>";
      //objeto=undefined
   };
     
   //alert(typeof rutaObjeto_ok === "undefined");
   //alert("rutaObjeto: " + rutaObjeto + "\nruta ok: " + rutaObjeto_ok + "\ntipo: " + typeof(objeto) + "\ncontenido:\n\n" + infoObjetoSimple(objeto));
   
   //Numero de propiedades evaluadas
   var txtNumProp="";
   var nProp=0;
   var nPropFiltro=0;
   for(var propertyName in objeto) {
      nProp++;
      if (propertyName.toLowerCase().indexOf(_mo_.nombreFiltro.toLowerCase())>=0)
         nPropFiltro++;
   };
   if (this.conFiltro)
      txtNumProp="Propiedades "+nPropFiltro+"/"+nProp+":";
   else
      txtNumProp=nProp+" propiedades:";
   txtNumProp="<br><small><small>"+txtNumProp+"</small></small>";
   //alert(txtNumProp);
   

   //====== Enlaces para navegacion ==========
   //var nav="<a href='javascript:location.reload();' title='Inicio'><font size=+2 color='darkred'>&#10148;</font></a> ";
   var nav="[<a href='#' onclick='divResult.style.display=\"none\"' title='Cerrar área' style='text-decoration:none;'><font size=+1 color='darkred'>&#x2715;</font></a>] ";
   var txtCopy="<p align=right><font size='-2' color='silver'><i>(C) JAC 2017</i></font>&nbsp;</p>";
   var navCompleto="";
   var punto=".";
   
   var arrRuta = rutaObjeto.split(".");
   for (i=0;i<arrRuta.length;i++) {
     //alert("sub arrRuta: " + arrRuta[i]);
     punto=(i==0)?"":".";
     navCompleto+= punto + arrRuta[i];
     //nav+=arrRuta[i] + "  " + navCompleto + "\n";
     nav+=punto + "<a href='javascript:_mo_.mostrarObjetoHTML( \"" + navCompleto + "\" ,\""+this.nombreFiltro+"\" );'>" + arrRuta[i] + "</a>";
   };
   //alert(nav);
   if (typeof(objeto)==="function"){
        nav="<h3>" + nav + txtNumProp+"</h3><b>" + objeto + "</b>";
        //alert("funcion " + objeto);
        nav=nav + "<p><b>Llamada:</b><a href='javascript:_mo_.mostrarObjetoHTML( \"" + rutaObjeto_ok + "()\" ,\""+this.nombreFiltro+"\" );'>" + rutaObjeto_ok + "()</a> con "+objeto.length+" argumentos</p>";
      
      
         //-------- Mensajes de error -------------
         try{
            objeto=eval(rutaObjeto_ok + "()");
         } catch (err) {
            txtError+="<p><b>Error:</b><i>"+err+"</i></p>";
            //objeto=undefined
         };
      
        nav=nav + "<p><b>Retorno:</b> " + objeto + "</p>";
    } else if (Array.isArray(objeto)){
        nav="<h3>" + nav + " Array(" + objeto.length + ")"+txtNumProp+"</h3>";
    } else{
        nav="<h3>" + nav + " " + objeto +  txtNumProp+"</h3>";
    };
  //====== Propiedades Objeto ==========
  //alert(objeto);
  var nProp=0;
  for(var propertyName in objeto) {
        nProp++;
        //alert("Propiedad: "+ propertyName + "   (filtro '" + this.nombreFiltro +"'= "+
        //(propertyName.toLowerCase().indexOf(this.nombreFiltro.toLowerCase())>=0)+")");
     
        var txtProp="";
        if (typeof(objeto[propertyName])=="function") {
            txtProp="<a href='javascript:_mo_.mostrarObjetoHTML( \"" + rutaObjeto + "." + propertyName + "\" ,\""+this.nombreFiltro+"\" );'>function</a>" +
               "&nbsp;&nbsp;&nbsp;" +
               "<small><a href='javascript:_mo_.mostrarObjetoHTML( \"" + rutaObjeto + "." + propertyName + "()\" ,\""+this.nombreFiltro+"\" );'>(ejecutar)</a></small>";
        } else if (Array.isArray(objeto[propertyName])) {
            
            if (isFinite(propertyName)){ //Si la propiedad es un entero
                //alert(propertyName + " es entero");
                txtProp="<a href='javascript:_mo_.mostrarObjetoHTML( \"" + rutaObjeto + ".[" + propertyName + "]\" ,\""+this.nombreFiltro+"\" );'>Array(" + objeto[propertyName].length + ")</a>";
            } else {
                //alert(propertyName + " NO es entero");
                txtProp="<a href='javascript:_mo_.mostrarObjetoHTML( \"" + rutaObjeto + "." + propertyName + "\" ,\""+this.nombreFiltro+"\" );'>Array(" + objeto[propertyName].length + ")</a>";
            };
        } else if ((typeof(objeto[propertyName])=="object") && (objeto[propertyName]!==null)) {
            
            if (isFinite(propertyName)){ //Si la propiedad es un entero
                //alert(propertyName + " es entero");
                txtProp="<a href='javascript:_mo_.mostrarObjetoHTML( \"" + rutaObjeto + ".[" + propertyName + "]\",\""+this.nombreFiltro+"\" );'>" + objeto[propertyName] + "</a>";
            } else {
                //alert(propertyName + " NO es entero");
                txtProp="<a href='javascript:_mo_.mostrarObjetoHTML( \"" + rutaObjeto + "." + propertyName + "\" ,\""+this.nombreFiltro+"\" );'>" + objeto[propertyName] + "</a>";
            };
            
        } else {
            txtProp= objeto[propertyName];// + " " + typeof(objeto[propertyName]);
        };
        
        //return " <a href='javascript:_mo_.mostrarObjetoHTML( " + rutaObjeto + " );'>objeto</a>";;
     
     //Mostrar si no va con filtro, o si va con filtro y encuentra
     if ((!this.conFiltro)||
         ((this.conFiltro)&&(propertyName.toLowerCase().indexOf(_mo_.nombreFiltro.toLowerCase())>=0))) {
          txtObjeto=txtObjeto + this.lpad(nProp,3) + ". " + this.adornaProp(propertyName) + txtProp + "\n";
        //this.rpad(propertyName,30)
     };
        
  }; //for
  txtObjeto="<pre>" + nav + txtError + txtObjeto + "</pre>" + txtCopy;
  return txtObjeto;
}, //infoObjeto
adornaProp: function(nombre){
   //return this.rpad(nombre,30);
   
   var pos1=nombre.toLowerCase().indexOf(_mo_.nombreFiltro.toLowerCase());
   var pos2=_mo_.nombreFiltro.length;
                          
   var txt=nombre.substr(0,pos1)+"<b>"+_mo_.nombreFiltro+"</b>"+nombre.substr(pos1+pos2);
   return this.rpad(txt,30);
},
//==========================================
// rpad, lpad
//==========================================
lpad: function(x,n) {
  var str = Array(100).join(' '); // make a string of 100 spaces
  return (str + x).slice(-n);
},
rpad: function(x,n) {
  var str = Array(100).join(' '); // make a string of 100 spaces
  return (x + str).substring(0, n);
},

}; //_mo_


_mo_.iniciar(_mo_.objetoInicial);

//==========================================
// infoObjetoSimple
//==========================================
function infoObjetoSimple(objeto0) {
  var objeto=eval(objeto0);
  var txt=objeto + "\n";
  for(var propertyName in objeto) {
      if ((""+objeto[propertyName]).substring(0,8)==="function") {
          //txt=txt + propertyName + "         (...function...)\n";
      } else {
          txt=txt + _mo_.rpad(propertyName,30) + objeto[propertyName] + "\n";
      };
  };
  //alert(txt);
  //" <a href='javascript:void()' onclick='alert( " + objeto0 + " );alert(123);return true;'>objeto</a>";
  return txt;
}; //infoObjeto


//
//*******************************************************************
//   Fin modulo
//*******************************************************************